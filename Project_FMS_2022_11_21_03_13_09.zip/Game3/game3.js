let contents = "";
var correctFlag3= false;
function game3Setup(){
  contents = '';
  background('lightgreen');
  currentActivity = 3;
  
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  game4Button.hide();
}

function game3Draw(){
  background('lightgreen');
  fill('black')
  text('Type square', 185, 90);
  textFont('futura');
  textSize(15);
  text(contents, 185, 115, width-40, height-40);
  
  if(contents == "square"){
    console.log(contents)
    correctFlag3=true;
    text("Correct!",30,185)
  }
  
}
function keyTyped(){
  //contents = contents + key;
  contents += key;
  
}
function keyReleased(){
  if (keyCode == BACKSPACE){
  contents = contents.substring(0, contents.length -1);
  }
  
  
}

