var circleX, circleY;

var circleSize;

var correctFlag= false;

function game1Preload(){
}

function game1Setup(){
  background(150);
  currentActivity = 1;
  correctFlag=false
  
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  game4Button.hide();
  
  circleX = 50;
  circleY = 200;
  circleSize = 70;
}

function game1Draw(){
  background('orange');
  
  fill('black');
  text('Click on red', 175, 100);
  fill(255,0,0)
  circle(50,200,70);
  fill(0,255,0)
  circle(150,200,70);
  fill(0,0,255)
  circle(250,200,70);
  fill(255,255,0)
  circle(350,200,70);
  if(correctFlag){
    text('Correct!',185,300)
  }
}
function mouseClicked(){
  
  var d = dist(mouseX, mouseY, 50,200);
  
  if(d < circleSize){
    console.log("I am here")
    correctFlag=true;
  }
}
