
var correctFlag4= false;

function game2Setup(){
  contents = '';
  background('rgba(0,255,0, 0.25)');
  currentActivity = 2;
  
  
  // Hide the Activity 2 button, show all the other buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  game4Button.hide();
}

function game2Draw(){
  background('rgba(0,255,0, 0.25)');
  fill(255,0,0)
  circle(200,150,70);
  fill('black');
  text('Type color and shape', 140, 50);
  textFont('futura');
  textSize(15);
  text(contents, 175, 200, width-40, height-40);
  if(contents == "red circle"){
    console.log(contents)
    correctFlag4=true;
    text("Correct!",175,250)
  }
}
function keyTyped(){
  //contents = contents + key;
  contents += key;
  
}
function keyReleased(){
  if (keyCode == BACKSPACE){
  contents = contents.substring(0, contents.length -1);
  }
}

  