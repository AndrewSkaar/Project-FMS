
var correctFlag2= false;
function game4Setup(){
  contents = '';
  background('#fae');
  currentActivity = 4;
  correctFlag2=false
  
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  game4Button.hide();
  
}

function game4Draw(){
  background('#fae');
  fill(0,255,0)
  circle(70,200,60)
  fill(0,255,0)
  circle(90,250,60)
  fill(0,255,0)
  circle(40,100,60)
  fill(0,255,0)
  circle(200,200,60)
  fill(0,255,0)
  circle(300,300,60)
  fill(0,255,0)
  circle(230,360,60)
  fill(0,255,0)
  circle(330,50,60)
  fill(0,255,0)
  circle(150,45,60)
  fill(0,255,0)
  circle(30,370,60)
  
  fill('black');
  text('Type how many circles are there?', 150, 100);
  
  fill('black');
  textFont('futura');
  textSize(15);
  text(contents, 240, 115, width-40, height-40);
  if(correctFlag2){
    text('Correct!',185,300)
  }
}
function keyTyped(){
  //contents = contents + key;
  contents += key;
  
}
function keyReleased(){
  if (keyCode == BACKSPACE){
    console.log("maybe youre here")
  contents = contents.substring(0, contents.length -1);
  }
  if(contents == '9'){
    correctFlag2=true;
  }
}
