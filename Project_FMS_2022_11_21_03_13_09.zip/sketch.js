/****
 * FSE100: examples for how to link multiple exercises together
 *****/

let currentActivity = 0;
let menuButton, game1Button, game2Button, game3Button, game4Button;

/***** 
  * If you want to load images or sounds into your application,
  * try using preload()
  * https://p5js.org/reference/#/p5/preload
  *****/
function preload(){
  game1Preload();
}

function switchToMM(){
  background(220);
  currentActivity = 0;
  
  // Hide the home page button, show the activity buttons
  menuButton.hide();
  game1Button.show();
  game2Button.show();
  game3Button.show();
  game4Button.show();
}

function setup() {
  createCanvas(400, 400);
  background(150);
  menuButton = createButton('Back');
  menuButton.position(5, 5);
  menuButton.mousePressed(switchToMM);
  menuButton.hide();
  
  
  game1Button = createButton('Click a Color');
  game1Button.style('background-color','red')
  game1Button.position(75, 150);
  game1Button.mousePressed(game1Setup);
  game1Button.show();
  
  game2Button = createButton('Colors and Shapes');
  game2Button.style('background-color','green')
  game2Button.position(225, 150);
  game2Button.mousePressed(game2Setup);
  game2Button.show();
  
  game3Button = createButton('Typing');
  game3Button.style('background-color','lightblue')
  game3Button.position(75, 250);
  game3Button.mousePressed(game3Setup);
  game3Button.show();
  
  game4Button = createButton('Counting');
  game4Button.style('background-color','yellow')
  game4Button.position(225, 250);
  game4Button.mousePressed(game4Setup);
  game4Button.show();
}


function draw() {  
  switch(currentActivity){
    case 0: 
      mainMenu();
      break;
    case 1: 
      game1Draw();
      break;
    case 2: 
      game2Draw();
      break;
    case 3: 
      game3Draw();
      break;
    case 4: 
      game4Draw();
      break;
  }
}

function mainMenu(){
  background(150);
  
  fill('black');
  textSize(25);
  text('iColor', 170, 100);


  
}